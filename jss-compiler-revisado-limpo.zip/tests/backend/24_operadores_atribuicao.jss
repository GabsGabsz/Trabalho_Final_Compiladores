﻿function void main() {
    let int x = 10;

    x += 5;
    x -= 3;
    x *= 2;
    x /= 4;
    x %= 3;

    console.log("X:", x);
}
